package com.chlordane.android.mobileinc;

import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * Created by ROG on 10/1/2017.
 */

public class TabFragmentDummy extends Fragment {

    public TabFragmentDummy() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }
}
